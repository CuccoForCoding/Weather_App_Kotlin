package com.cis2818.demoweek11joey.ui.main

import android.icu.text.SimpleDateFormat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.cis2818.demoweek11joey.R
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList

class MainViewModel : ViewModel() {
    private val API = "71147ffb05fa1f7353ffd4aa0549e65f"
    private var temp : MutableLiveData<String> = MutableLiveData()
    private var date : MutableLiveData<String> = MutableLiveData()
    private var icon : MutableLiveData<String> = MutableLiveData()
    private var desc : MutableLiveData<String> = MutableLiveData()

    private var list: MutableLiveData<ArrayList<Items>> = MutableLiveData()
    private var listItems: ArrayList<Items> = ArrayList()

    fun getTemp():MutableLiveData<String> {
        return temp
    }

    fun getDate():MutableLiveData<String> {
        return date
    }

    fun getIcon():MutableLiveData<String> {
        return icon
    }

    fun getDesc():MutableLiveData<String> {
        return desc
    }

    fun getList(): MutableLiveData<ArrayList<Items>> {
        return list
    }

    fun weather(city : String, queue: RequestQueue) {
        val url = "https://api.openweathermap.org/data/2.5/weather?q=$city&units=imperial&appid=$API"
        val stringRequest = StringRequest(Request.Method.GET, url, Response.Listener<String> { response ->
            // create JSONObject
            val obj = JSONObject(response)

            // get current weather information of a city
            val main = obj.getJSONObject("main")
            temp.setValue("%.0f° F".format(main.getDouble("temp")))

            val toDate = obj.getLong("dt")
            date.setValue(SimpleDateFormat("EEE, MMMM dd hh:mm a", Locale.ENGLISH).format(Date(toDate * 1000)))

            val weather = obj.getJSONArray("weather").getJSONObject(0)
            desc.setValue(weather.getString("description"))
            icon.setValue("https://api.openweathermap.org/img/w/${weather.getString("icon")}.png")
            },
            Response.ErrorListener { temp.setValue("0") })
            // Add the request to the RequestQueue.
                queue.add(stringRequest)
    }
    fun forecast(city : String, queue: RequestQueue) {
        listItems.clear()
        val url= "https://api.openweathermap.org/data/2.5/forecast?q=$city&units=imperial&appid=$API"
        val stringRequest = StringRequest(Request.Method.GET, url, Response.Listener<String> { response ->
                // create JSONObject
                val obj = JSONObject(response)
                val myList = obj.getJSONArray("list")
                for(i in 3..39 step 8) {
                    var info = myList.getJSONObject(i)
                    val toDate = info.getLong("dt")
                    var date =(SimpleDateFormat("EEE, MMMM dd", Locale.ENGLISH).format(Date(toDate * 1000)))
                    var temp = info.getJSONObject("main").getDouble("temp")
                    var icon = info.getJSONArray("weather").getJSONObject(0).getString("icon")
                    var iconURL = "https://api.openweathermap.org/img/w/$icon.png"
                    listItems.add(Items(date,"%.0f° F".format(temp), iconURL))


                }
                //	get 5day forecast information of a city
                list.setValue(listItems)
            },
            Response.ErrorListener { temp.setValue("0") });
            // Add the request to the RequestQueue.
                queue.add(stringRequest)
    }
}