package com.cis2818.demoweek11joey.ui.main

    data class Items(var date: String, var temp: String, var icon: String) {}
