package com.cis2818.demoweek11joey

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.cis2818.demoweek11joey.databinding.MainActivityBinding
import com.cis2818.demoweek11joey.databinding.MainFragmentBinding
import com.cis2818.demoweek11joey.ui.main.MainFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: MainActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = MainActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonFirst.setOnClickListener {
            val frag = supportFragmentManager.findFragmentById(R.id.fragmentContainer) as MainFragment
            frag.setCity(binding.editCity.text.toString())
        }

    }
}